Hey thx for downloading

How to install
------------------------------
1. Put files into tf/custom
1a. If u play on windows use QuoteHud
1b. If u play on linux use quotehud-linux 
2. Enjoy
2a. If any bugs, contact me via steam 

My steam quotestrife
twitter @quote_strife

If dimmer (black shadow when u click find a 
game appears even with Remove Dimmer installed)
still appears, let me know.


WARNING
------------------------------------
DO NOT USE REMOVE DIMMER IF YOU HAVE A CUSTOM 
AUTOEXEC.CFG OR VALVE.RC, INSTEAD COPY THE CODE 
INSIDE TO YOUR AUTOEXEC.CFG/VALVE.RC
IF YOU HAVE NO IDEA WHAT I AM TALKING ABOUT
YOU ARE FINE IGNORE THE WARNING
------------------------------------

Pipboy ain't supported :(

also if damage numbers are red put this in autoexec.cfg
hud_combattext_red 255
hud_combattext_green 255
hud_combattext_blue 255

also if you want the netgraph thing in the scoreboard use this in autoexec.cfg
alias +pinger "+score; net_graph 1"
alias -pinger "-score; net_graph 0"
bind "TAB" "+pinger"



Credits
broesel-tf - made broeselhud
Broeselhud_blue - mod of broeselhud
Bearshud - modded hud I used for QuoteHUD
AlexCookie - backgrounds
Rurre - base reworked loadout screen
Acid Archos - used to see what file a bug in my HUD was in (no files of his are in QuoteHud)
QuoteStrife (hey thats me) - QuoteHud